﻿namespace GameStore.DAL.Entities
{
	public class Shipper : BaseEntity
	{
		public string CompanyName { get; set; }

		public string Phone { get; set; }
	}
}